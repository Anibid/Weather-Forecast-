const apiKey = 'e456fdfb9ba6f7d4f7b1f08615e394d9'; // Replace with your actual API key
const apiUrl = 'https://api.openweathermap.org/data/2.5';

function getWeatherByCity(city = null) {
  if (!city) city = document.getElementById('cityInput').value;
  if (!city) {
    alert("Please enter a city name.");
    return;
  }

  fetch(`${apiUrl}/weather?q=${city}&appid=${apiKey}&units=metric`)
    .then(response => response.json())
    .then(data => {
      if (data.cod !== 200) throw new Error(data.message);
      displayCurrentWeather(data);
      getExtendedForecast(city);
    })
    .catch(error => {
      alert(`Error: ${error.message}`);
    });
}

function getWeatherByCurrentLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(position => {
      const { latitude, longitude } = position.coords;
      fetch(`${apiUrl}/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=metric`)
        .then(response => response.json())
        .then(data => {
          if (data.cod !== 200) throw new Error(data.message);
          displayCurrentWeather(data);
          getExtendedForecast(data.name);
        })
        .catch(error => {
          alert(`Error: ${error.message}`);
        });
    });
  } else {
    alert("Geolocation is not supported by this browser.");
  }
}

function displayCurrentWeather(data) {
  const weatherDisplay = document.getElementById('weatherDisplay');
  const { name, main, weather, wind } = data;
  
  weatherDisplay.innerHTML = `
    <div class="text-white">
      <h2 class="text-xl font-semibold">${name} (${new Date().toISOString().split('T')[0]})</h2>
      <p>Temperature: ${main.temp}°C</p>
      <p>Wind: ${wind.speed} m/s</p>
      <p>Humidity: ${main.humidity}%</p>
      <p class="text-lg font-semibold">${weather[0].description}</p>
    </div>
  `;
  weatherDisplay.classList.remove('hidden');
}

function getExtendedForecast(city) {
  fetch(`${apiUrl}/forecast?q=${city}&appid=${apiKey}&units=metric`)
    .then(response => response.json())
    .then(data => {
      if (data.cod !== '200') throw new Error(data.message);
      displayExtendedForecast(data);
    })
    .catch(error => {
      alert(`Error: ${error.message}`);
    });
}

function displayExtendedForecast(data) {
  const forecastDisplay = document.getElementById('forecastDisplay');
  forecastDisplay.innerHTML = '';
  
  const forecastByDay = data.list.filter((_, index) => index % 8 === 0);
  forecastByDay.forEach(forecast => {
    const date = new Date(forecast.dt * 1000);
    forecastDisplay.innerHTML += `
      <div class="bg-gray-800 text-white p-4 rounded-lg text-center">
        <p class="font-semibold">${date.toISOString().split('T')[0]}</p>
        <p>${forecast.weather[0].main}</p>
        <img src="http://openweathermap.org/img/wn/${forecast.weather[0].icon}.png" alt="weather icon" class="mx-auto my-2">
        <p>Temp: ${forecast.main.temp}°C</p>
        <p>Wind: ${forecast.wind.speed} m/s</p>
        <p>Humidity: ${forecast.main.humidity}%</p>
      </div>
    `;
  });
}
